#ifndef ROOMINFO_H
#define ROOMINFO_H

#include <QDialog>

namespace Ui {
class roominfo;
}

class roominfo : public QDialog
{
    Q_OBJECT

public:
    explicit roominfo(QWidget *parent = nullptr);
    ~roominfo();

private:
    Ui::roominfo *ui;
};

#endif // ROOMINFO_H
