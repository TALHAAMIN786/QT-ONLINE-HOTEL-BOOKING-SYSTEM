#ifndef SERVICEDETAIL_H
#define SERVICEDETAIL_H

#include <QDialog>

namespace Ui {
class servicedetail;
}

class servicedetail : public QDialog
{
    Q_OBJECT

public:
    explicit servicedetail(QWidget *parent = nullptr, int roomCost = 0); // Constructor with roomCost
    ~servicedetail();

    int getServiceCost() const; // Function to return the service cost

private slots:
    void on_checkBox_checkStateChanged(const Qt::CheckState &arg1);
    void on_checkBox_2_checkStateChanged(const Qt::CheckState &arg1);
    void on_checkBox_3_checkStateChanged(const Qt::CheckState &arg1);
    void on_checkBox_4_checkStateChanged(const Qt::CheckState &arg1);
    void on_checkBox_5_checkStateChanged(const Qt::CheckState &arg1);
    void on_pushButton_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::servicedetail *ui;
    int serviceCost; // To store the total service cost
    int roomCost;    // To store the room cost passed from nxt
};

#endif // SERVICEDETAIL_H
