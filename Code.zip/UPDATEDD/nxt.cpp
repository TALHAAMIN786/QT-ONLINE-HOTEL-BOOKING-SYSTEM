#include "nxt.h"
#include "ui_nxt.h"
#include <roominfo.h>
#include <checkincheckout.h>
#include <services.h>
#include <QMessageBox>
#include <servicedetail.h>
#include <fstream> // For binary file handling
#include<bills.h>
nxt::nxt(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::nxt)
{
    ui->setupUi(this);
    ui->tableWidget->setColumnWidth(0,150);
    ui->tableWidget->setColumnWidth(1,150);
    ui->tableWidget->setColumnWidth(2,150);
    ui->tableWidget->setRowHeight(0,100);
    ui->tableWidget->setRowHeight(1,100);
    ui->tableWidget->setRowHeight(2,100);
    ui->tableWidget->setRowHeight(3,100);
    totalBill = 0; // Initialize totalBill to 0
}

nxt::~nxt()
{
    delete ui;
}

int nxt::getroomCost() const
{
    return totalBill;
}

void nxt::on_pushButton_2_clicked()
{
    roominfo *sec = new roominfo(this);
    sec->setModal(true);
    sec->exec();
}


void nxt::on_pushButton_clicked()
{
    checkincheckout *sec = new checkincheckout(this);
    sec->setModal(true);
    sec->exec();
}


void nxt::on_checkBox1_2_checkStateChanged(const Qt::CheckState &arg1)
{
    if (ui->checkBox1_2->isChecked()) {
        ui->comboBox_5->setEnabled(true);
    } else {
        ui->comboBox_5->setEnabled(false);
    }
}


void nxt::on_checkBox2_2_checkStateChanged(const Qt::CheckState &arg1)
{
    if (ui->checkBox2_2->isChecked()) {
        ui->comboBox_6->setEnabled(true);
    } else {
        ui->comboBox_6->setEnabled(false);
    }
}


void nxt::on_checkBox3_2_checkStateChanged(const Qt::CheckState &arg1)
{
    if (ui->checkBox3_2->isChecked()) {
        ui->comboBox_7->setEnabled(true);
    } else {
        ui->comboBox_7->setEnabled(false);
    }
}


void nxt::on_checkBox4_2_checkStateChanged(const Qt::CheckState &arg1)
{
    if (ui->checkBox4_2->isChecked()) {
        ui->comboBox_8->setEnabled(true);
    } else {
        ui->comboBox_8->setEnabled(false);
    }
}


void nxt::on_pushButton_3_clicked()
{
    totalBill = 0; // Reset totalBill
    bool isAnyRoomSelected = false;

    // Calculate room costs based on selected checkboxes and combo box values
    if (ui->checkBox1_2->isChecked()) {
        isAnyRoomSelected = true;
        int numberOfRooms = ui->comboBox_5->currentIndex() + 1;
        totalBill += numberOfRooms * 10000;
    }

    if (ui->checkBox2_2->isChecked()) {
        isAnyRoomSelected = true;
        int numberOfRooms = ui->comboBox_6->currentIndex() + 1;
        totalBill += numberOfRooms * 20000;
    }

    if (ui->checkBox3_2->isChecked()) {
        isAnyRoomSelected = true;
        int numberOfRooms = ui->comboBox_7->currentIndex() + 1;
        totalBill += numberOfRooms * 30000;
    }

    if (ui->checkBox4_2->isChecked()) {
        isAnyRoomSelected = true;
        int numberOfRooms = ui->comboBox_8->currentIndex() + 1;
        totalBill += numberOfRooms * 40000;
    }

    // Check if at least one checkbox is selected
    if (!isAnyRoomSelected) {
        QMessageBox::warning(this, "No Selection",
                             "Please select at least one room option to proceed.");
        return;
    }

    // Open services dialog
    servicedetail *sec = new servicedetail(this, totalBill);
    sec->setModal(true);
    sec->exec();

    // Add service cost to total bill
    int serviceCost = sec->getServiceCost();
    totalBill += serviceCost;

    // Display the overall bill
    QMessageBox::information(this, "Overall Bill",
                             "<h2 style='color: white; background-color: black; text-align: center; font-family: \"Times New Roman\";'>Hotel Billing Summary</h2>"
                             "<table border='1' cellspacing='0' cellpadding='5' style='width: 100%; border-collapse: collapse; font-family: \"Times New Roman\";'>"
                             "    <tr style='background-color: black; color: white; text-align: left;'>"
                             "        <th>Item</th>"
                             "        <th>Cost (Rs.)</th>"
                             "    </tr>"
                             "    <tr style='background-color: white; color: black;'>"
                             "        <td>Room Cost</td>"
                             "        <td>" + QString::number(totalBill - serviceCost) + "</td>"
                                                                              "    </tr>"
                                                                              "    <tr style='background-color: white; color: black;'>"
                                                                              "        <td>Service Cost</td>"
                                                                              "        <td>" + QString::number(serviceCost) + "</td>"
                                                                  "    </tr>"
                                                                  "    <tr style='background-color: black; color: white; font-weight: bold;'>"
                                                                  "        <td>Total Bill</td>"
                                                                  "        <td>" + QString::number(totalBill) + "</td>"
                                                                "    </tr>"
                                                                "</table>");

    // Save bill data to a binary file and show a message based on the result
    if (saveBillDataToFile("bill_data.bin")) {
        QMessageBox::information(this, "Success", "Bill data has been successfully saved.");
    } else {
        QMessageBox::critical(this, "Error", "Failed to save bill data.");
    }
}

bool nxt::saveBillDataToFile(const std::string &filename)
{
    std::ofstream outFile(filename, std::ios::binary);
    if (!outFile) {
        return false; // Indicate failure
    }

    // Write total bill
    outFile.write(reinterpret_cast<const char *>(&totalBill), sizeof(totalBill));

    // Save room details
    int room1Count = ui->checkBox1_2->isChecked() ? ui->comboBox_5->currentIndex() + 1 : 0;
    int room2Count = ui->checkBox2_2->isChecked() ? ui->comboBox_6->currentIndex() + 1 : 0;
    int room3Count = ui->checkBox3_2->isChecked() ? ui->comboBox_7->currentIndex() + 1 : 0;
    int room4Count = ui->checkBox4_2->isChecked() ? ui->comboBox_8->currentIndex() + 1 : 0;

    outFile.write(reinterpret_cast<const char *>(&room1Count), sizeof(room1Count));
    outFile.write(reinterpret_cast<const char *>(&room2Count), sizeof(room2Count));
    outFile.write(reinterpret_cast<const char *>(&room3Count), sizeof(room3Count));
    outFile.write(reinterpret_cast<const char *>(&room4Count), sizeof(room4Count));

    outFile.close();
    return true; // Indicate success
}

void nxt::loadBillDataFromFile(const std::string &filename)
{
    std::ifstream inFile(filename, std::ios::binary);
    if (!inFile) {
        QMessageBox::critical(this, "Error", "Failed to load bill data from file.");
        return;
    }

    // Read total bill
    inFile.read(reinterpret_cast<char *>(&totalBill), sizeof(totalBill));

    // Read room details
    int room1Count, room2Count, room3Count, room4Count;
    inFile.read(reinterpret_cast<char *>(&room1Count), sizeof(room1Count));
    inFile.read(reinterpret_cast<char *>(&room2Count), sizeof(room2Count));
    inFile.read(reinterpret_cast<char *>(&room3Count), sizeof(room3Count));
    inFile.read(reinterpret_cast<char *>(&room4Count), sizeof(room4Count));

    // Update UI
    ui->checkBox1_2->setChecked(room1Count > 0);
    ui->comboBox_5->setCurrentIndex(room1Count > 0 ? room1Count - 1 : 0);

    ui->checkBox2_2->setChecked(room2Count > 0);
    ui->comboBox_6->setCurrentIndex(room2Count > 0 ? room2Count - 1 : 0);

    ui->checkBox3_2->setChecked(room3Count > 0);
    ui->comboBox_7->setCurrentIndex(room3Count > 0 ? room3Count - 1 : 0);

    ui->checkBox4_2->setChecked(room4Count > 0);
    ui->comboBox_8->setCurrentIndex(room4Count > 0 ? room4Count - 1 : 0);

    inFile.close();
    QMessageBox::information(this, "Success", "Bill data loaded successfully.");
}

void nxt::on_pushButton_4_clicked()
{
    Bills *sec = new Bills(this);
   // sec->setModal(true);
  // sec->exec();
}




