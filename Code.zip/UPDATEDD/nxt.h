#ifndef NXT_H
#define NXT_H

#include <QDialog>

namespace Ui {
class nxt;
}

class nxt : public QDialog
{
    Q_OBJECT

public:
    explicit nxt(QWidget *parent = nullptr);
    int getroomCost() const;
    ~nxt();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

    void on_checkBox1_2_checkStateChanged(const Qt::CheckState &arg1);

    void on_checkBox2_2_checkStateChanged(const Qt::CheckState &arg1);

    void on_checkBox3_2_checkStateChanged(const Qt::CheckState &arg1);

    void on_checkBox4_2_checkStateChanged(const Qt::CheckState &arg1);

    void on_pushButton_3_clicked();

    void on_comboBox_6_activated(int index);

    void on_comboBox_8_activated(int index);

    void on_comboBox_7_activated(int index);

    void on_comboBox_5_activated(int index);

    void on_pushButton_4_clicked();

private:
    Ui::nxt *ui;
    int totalBill;

    // Declare the save and load functions
    bool saveBillDataToFile(const std::string &filename);
    void loadBillDataFromFile(const std::string &filename);
};
#endif // NXT_H
