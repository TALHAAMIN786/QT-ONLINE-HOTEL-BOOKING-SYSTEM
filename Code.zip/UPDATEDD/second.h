#ifndef SECOND_H
#define SECOND_H

#include <QDialog>

namespace Ui {
class second;
}

class second : public QDialog
{
    Q_OBJECT

public:
    explicit second(QWidget *parent = nullptr);
    ~second();

private slots:
    void on_buttonBox_accepted();
    void on_buttonBox_rejected();

    void on_label_linkActivated(const QString &link);

private:
    Ui::second *ui;
};

#endif // SECOND_H
