#include "second.h"
#include "ui_second.h"
#include <QPushButton>
#include<nxt.h>
second::second(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::second)
{
    ui->setupUi(this);

    // Set a gradient background for the window
    this->setStyleSheet(R"(
        QWidget {
            background: qlineargradient(
                spread:pad, x1:0, y1:0, x2:1, y2:1,
                stop:0 #1E3C72, stop:1 #2A5298
            );
        }
    )");

    // Style the "WELCOME" label with a clean and modern look
    ui->label->setStyleSheet(R"(
        QLabel {
            font-size: 32px;
            font-weight: bold;
            color: #FFFFFF;
            text-shadow: 3px 3px 6px #000000;
            background: transparent;
            border: none;  /* Removes any borders */
            padding: 10px;
        }
    )");
    ui->label->setAlignment(Qt::AlignCenter);

    // Style all other labels with a clean font and transparent background
    QString labelStyle = R"(
        QLabel {
            font-size: 16px;
            font-weight: bold;
            color: #E0E0E0;
            background: transparent;
            border: none;
            margin: 5px 0;
        }
    )";
    ui->label_2->setStyleSheet(labelStyle);
    ui->label_3->setStyleSheet(labelStyle);
    ui->label_4->setStyleSheet(labelStyle);
    ui->label_5->setStyleSheet(labelStyle);
    ui->label_6->setStyleSheet(labelStyle);
    ui->label_7->setStyleSheet(labelStyle);
    ui->label_8->setStyleSheet(labelStyle);
    ui->label_9->setStyleSheet(labelStyle);

    // Style the "OK" and "Cancel" buttons with a polished modern design
    ui->buttonBox->button(QDialogButtonBox::Ok)->setStyleSheet(R"(
        QPushButton {
            background-color: #4CAF50;
            color: white;
            border-radius: 12px;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
        }
        QPushButton:hover {
            background-color: #66BB6A;
        }
        QPushButton:pressed {
            background-color: #388E3C;
        }
    )");

    ui->buttonBox->button(QDialogButtonBox::Cancel)->setStyleSheet(R"(
        QPushButton {
            background-color: #F44336;
            color: white;
            border-radius: 12px;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
        }
        QPushButton:hover {
            background-color: #E57373;
        }
        QPushButton:pressed {
            background-color: #D32F2F;
        }
    )");

    // Align labels neatly
    ui->label_2->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
    ui->label_3->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
    ui->label_4->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
    ui->label_5->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
    ui->label_6->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
    ui->label_7->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
    ui->label_8->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);
    ui->label_9->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);

    // Connect signals and slots for button actions
    connect(ui->buttonBox, &QDialogButtonBox::accepted, this, &second::on_buttonBox_accepted);
    connect(ui->buttonBox, &QDialogButtonBox::rejected, this, &second::on_buttonBox_rejected);
}

second::~second()
{
    delete ui;
}

void second::on_buttonBox_accepted()
{        nxt *sec = new nxt(this);
    sec->setModal(true);
    sec->exec();

    this->accept(); // Close the window when OK is clicked
}

void second::on_buttonBox_rejected()
{
    // Logic when 'Cancel' button is clicked
    this->reject(); // Close the window when Cancel is clicked
}
