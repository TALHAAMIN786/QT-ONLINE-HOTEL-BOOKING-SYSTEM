#include "services.h"
#include "ui_services.h"
#include<QApplication>
#include<QMessageBox>
#include<QPixmap>
#include<servicedetail.h>
services::services(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::services)
{
    ui->setupUi(this);
    QPixmap pix1=QPixmap(":/img/WhatsApp Image 2023-12-24 at 8.00.29 PM.jpeg");
    ui->label_7->setPixmap(pix1.scaled (300,300,Qt::KeepAspectRatio));
    QPixmap pix2=QPixmap(":/img/WhatsApp Image 2023-12-24 at 8.12.15 PM.jpeg");
    ui->label_9->setPixmap(pix2.scaled (300,300,Qt::KeepAspectRatio));
    QPixmap pix3=QPixmap(":/img/WhatsApp Image 2023-12-24 at 8.12.16 PM.jpeg");
    ui->label_10->setPixmap(pix3.scaled (300,300,Qt::KeepAspectRatio));
    QPixmap pix4=QPixmap(":/img/WhatsApp Image 2023-12-24 at 8.12.17 PM.jpeg");
    ui->label_11->setPixmap(pix4.scaled (300,300,Qt::KeepAspectRatio));
    QPixmap pix5=QPixmap(":/img/WhatsApp Image 2023-12-24 at 8.12.38 PM.jpeg");
    ui->label_8->setPixmap(pix5.scaled (300,300,Qt::KeepAspectRatio));
}

services::~services()
{
    delete ui;
}



void services::on_label_3_linkActivated(const QString &link)
{

}


void services::on_pushButton_clicked()
{
    servicedetail *sec = new servicedetail(this);
    sec->setModal(true);
    sec->exec();
}

