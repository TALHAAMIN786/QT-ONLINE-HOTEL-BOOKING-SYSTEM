#include "checkincheckout.h"
#include "ui_checkincheckout.h"
#include<QDebug>
#include<QDateEdit>
checkincheckout::checkincheckout(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::checkincheckout)
{
    ui->setupUi(this);
}

checkincheckout::~checkincheckout()
{
    delete ui;
}



void checkincheckout::on_dateEdit_2_userDateChanged(const QDate &date)
{
    qDebug()<<"Your selected dates are"<<date;
}


void checkincheckout::on_dateEdit_userDateChanged(const QDate &date)
{
    qDebug()<<"Your selected dates are"<<date;
}

