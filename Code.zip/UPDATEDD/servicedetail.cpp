#include "servicedetail.h"
#include "ui_servicedetail.h"

#include <QMessageBox>
#include<QPixmap>
servicedetail::servicedetail(QWidget *parent, int roomCost)
    : QDialog(parent)
    , ui(new Ui::servicedetail)
    , serviceCost(0) // Initialize serviceCost
    , roomCost(roomCost) // Initialize roomCost
{
    ui->setupUi(this);
    QPixmap pix1=QPixmap(":/img/WhatsApp Image 2023-12-24 at 8.00.29 PM.jpeg");
    ui->label_13->setPixmap(pix1.scaled (300,300,Qt::KeepAspectRatio));
    QPixmap pix2=QPixmap(":/img/WhatsApp Image 2023-12-24 at 8.12.15 PM.jpeg");
    ui->label_14->setPixmap(pix2.scaled (300,300,Qt::KeepAspectRatio));
    QPixmap pix3=QPixmap(":/img/WhatsApp Image 2023-12-24 at 8.12.16 PM.jpeg");
    ui->label_16->setPixmap(pix3.scaled (300,300,Qt::KeepAspectRatio));
    QPixmap pix4=QPixmap(":/img/WhatsApp Image 2023-12-24 at 8.12.17 PM.jpeg");
    ui->label_17->setPixmap(pix4.scaled (300,300,Qt::KeepAspectRatio));
    QPixmap pix5=QPixmap(":/img/WhatsApp Image 2023-12-24 at 8.12.38 PM.jpeg");
    ui->label_20->setPixmap(pix5.scaled (300,300,Qt::KeepAspectRatio));
}


servicedetail::~servicedetail()
{
    delete ui;
}
int servicedetail::getServiceCost() const
{
    return serviceCost; // Return the service cost
}

void servicedetail::on_checkBox_checkStateChanged(const Qt::CheckState &arg1)
{
    if (ui->checkBox->isChecked()) {
        serviceCost += 2000; // Add swimming pool service cost
    } else {
        serviceCost -= 2000; // Remove swimming pool service cost
    }
}

void servicedetail::on_checkBox_2_checkStateChanged(const Qt::CheckState &arg1)
{
    if (ui->checkBox_2->isChecked()) {
        serviceCost += 1000; // Add gym service cost
    } else {
        serviceCost -= 1000; // Remove gym service cost
    }
}

void servicedetail::on_checkBox_3_checkStateChanged(const Qt::CheckState &arg1)
{
    if (ui->checkBox_3->isChecked()) {
        serviceCost += 2000; // Add gym service cost
    } else {
        serviceCost -= 2000; // Remove gym service cost
    }
}

void servicedetail::on_checkBox_4_checkStateChanged(const Qt::CheckState &arg1)
{
    if (ui->checkBox_4->isChecked()) {
        serviceCost += 1500; // Add sports facilities cost
    } else {
        serviceCost -= 1500; // Remove sports facilities cost
    }
}

void servicedetail::on_checkBox_5_checkStateChanged(const Qt::CheckState &arg1)
{
    if (ui->checkBox_5->isChecked()) {
        serviceCost += 2500; // Add food facilities cost
    } else {
        serviceCost -= 2500; // Remove food facilities cost
    }
}

void servicedetail::on_pushButton_clicked()
{
    // Check if at least one checkbox is checked
    if (ui->checkBox_5->isChecked() ||
        ui->checkBox_4->isChecked() ||
        ui->checkBox_3->isChecked() ||
        ui->checkBox_2->isChecked() ||
        ui->checkBox->isChecked()) {
        // Display the overall bill
     //   QMessageBox::information(this, "Overall Bill", "The total service cost is Rs. " + QString::number(serviceCost));
    } else {
        // Show warning if no checkboxes are selected
        QMessageBox::warning(this, "Warning", "Please select at least one service to proceed.");
    }
}

void servicedetail::on_pushButton_4_clicked()
{
     this->close();
}

