#include "signup.h"
#include "ui_signup.h"
#include <QFile>
#include <QDataStream>
#include <QMessageBox>
#include<mainwindow.h>

signup::signup(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::signup)
{
    ui->setupUi(this);

    // Apply custom styles for the MainWindow
    this->setStyleSheet(R"(
      QDialog {
            background-color: #1A1A2E; /* Dark navy blue background */
        }

        QLabel {
            color: #FFFFFF; /* White text color for labels */
            font-size: 14px;
            font-weight: bold;
        }
 QLabel#label_3  {
            color: #FFD700; /* Golden yellow for contrast */
            font-size: 28px; /* Larger font size for prominence */
            font-weight: 600; /* Slightly less bold for a professional touch */
            text-align: center; /* Centered text */
            font-family: "Arial", sans-serif; /* Clean, professional font */
            margin-bottom: 20px; /* Spacing below the label */
        }

        QLineEdit {
            background-color: #0F3460; /* Slightly lighter blue for input fields */
            color: #FFFFFF; /* White text color */
            border: 2px solid #4CAF50; /* Green border for style */
            border-radius: 8px; /* Rounded corners */
            padding: 5px; /* Padding inside the text fields */
            font-size: 12px;
        }

        QLineEdit:focus {
            border: 2px solid #00ADB5; /* Highlighted teal border when focused */
        }

        QPushButton {
            background-color: #4CAF50; /* Green button background */
            color: #FFFFFF; /* White button text */
            border-radius: 8px; /* Rounded corners */
            padding: 8px 15px; /* Padding for a larger button */
            font-size: 14px;
            font-weight: bold;
        }

        QPushButton:hover {
            background-color: #66BB6A; /* Lighter green on hover */
        }

        QPushButton:pressed {
            background-color: #388E3C; /* Darker green when pressed */
        }
    )");

    // Set placeholder text for the username and password fields
    ui->lineEdit_name->setPlaceholderText("Enter your username");
    ui->lineEdit_password->setPlaceholderText("Enter your password");

    // Make the password field hide the entered text
    ui->lineEdit_password->setEchoMode(QLineEdit::Password);
}

signup::~signup()
{
    delete ui;
}
// Function to save user credentials in a binary file
void saveCredentials(const QString &username, const QString &password)
{
    QFile file("credentials.dat");
    if (!file.open(QIODevice::WriteOnly)) {
        QMessageBox::critical(nullptr, "Error", "Failed to open file for saving credentials.");
        return;
    }

    QDataStream out(&file);
    out << username << password;
    file.close();

    QMessageBox::information(nullptr, "Registration Successful",
                             "<p style='color:#4CAF50; font-weight:bold;'>"
                             "Your credentials have been saved successfully!</p>");
}

void signup::on_pushButton_clicked()
{
    QString username = ui->lineEdit_name->text();
    QString password = ui->lineEdit_password->text();

    if (username.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "Incomplete Details",
                             "<p style='color:#E94560; font-weight:bold;'>"
                             "Please enter both username and password to register.</p>");
        return;
    }

    saveCredentials(username, password);
    this->close();
    // Open the main login window
    MainWindow *loginWindow = new MainWindow();
    loginWindow->show();
}


void signup::on_pushButton_3_clicked()
{
    this->close();
    // Open the main login window
    MainWindow *loginWindow = new MainWindow();
    loginWindow->show();
}

