#include "roominfo.h"
#include "ui_roominfo.h"
#include<QPixmap>

roominfo::roominfo(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::roominfo)
{
    ui->setupUi(this);
    QPixmap pix1=QPixmap(":/img/12.png");
    ui->label1->setPixmap(pix1.scaled (400,400,Qt::KeepAspectRatio));
    QPixmap pix2=QPixmap(":/img/11.png");
    ui->label2->setPixmap(pix2.scaled (400,400,Qt::KeepAspectRatio));
    QPixmap pix3=QPixmap(":/img/10.png");
    ui->label3->setPixmap(pix3.scaled (400,400,Qt::KeepAspectRatio));
    QPixmap pix4=QPixmap(":/img/13.png");
    ui->label4->setPixmap(pix4.scaled (400,400,Qt::KeepAspectRatio));
}

roominfo::~roominfo()
{
    delete ui;
}



