#include "mainwindow.h"
#include<signup.h>
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    signup w;
    w.show();
    return a.exec();
}
