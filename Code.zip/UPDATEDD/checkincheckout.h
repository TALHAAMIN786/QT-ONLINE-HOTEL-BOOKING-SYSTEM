#ifndef CHECKINCHECKOUT_H
#define CHECKINCHECKOUT_H

#include <QDialog>

namespace Ui {
class checkincheckout;
}

class checkincheckout : public QDialog
{
    Q_OBJECT

public:
    explicit checkincheckout(QWidget *parent = nullptr);
    ~checkincheckout();

private slots:
    void on_dateEdit_2_userDateChanged(const QDate &date);

    void on_dateEdit_userDateChanged(const QDate &date);

private:
    Ui::checkincheckout *ui;
};

#endif // CHECKINCHECKOUT_H
