#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include "second.h"
#include <QFile>
#include <QDataStream>
#include<signup.h>
#include<QPixmap>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Apply custom styles for the MainWindow
    this->setStyleSheet(R"(
        QMainWindow {
            background-color: #1A1A2E; /* Dark navy blue background */
        }

        QLabel {
            color: #FFFFFF; /* White text color for labels */
            font-size: 14px;
            font-weight: bold;
        }
 QLabel#label_3  {
            color: #FFD700; /* Golden yellow for contrast */
            font-size: 28px; /* Larger font size for prominence */
            font-weight: 600; /* Slightly less bold for a professional touch */
            text-align: center; /* Centered text */
            font-family: "Arial", sans-serif; /* Clean, professional font */
            margin-bottom: 20px; /* Spacing below the label */
        }
        QLineEdit {
            background-color: #0F3460; /* Slightly lighter blue for input fields */
            color: #FFFFFF; /* White text color */
            border: 2px solid #4CAF50; /* Green border for style */
            border-radius: 8px; /* Rounded corners */
            padding: 5px; /* Padding inside the text fields */
            font-size: 12px;
        }

        QLineEdit:focus {
            border: 2px solid #00ADB5; /* Highlighted teal border when focused */
        }

        QPushButton {
            background-color: #4CAF50; /* Green button background */
            color: #FFFFFF; /* White button text */
            border-radius: 8px; /* Rounded corners */
            padding: 8px 15px; /* Padding for a larger button */
            font-size: 14px;
            font-weight: bold;
        }

        QPushButton:hover {
            background-color: #66BB6A; /* Lighter green on hover */
        }

        QPushButton:pressed {
            background-color: #388E3C; /* Darker green when pressed */
        }
    )");
    // Set placeholder text for the username and password fields
    ui->lineEdit_name->setPlaceholderText("Enter your username");
    ui->lineEdit_password->setPlaceholderText("Enter your password");

    // Make the password field hide the entered text
    ui->lineEdit_password->setEchoMode(QLineEdit::Password);
}

MainWindow::~MainWindow()
{
    delete ui;
}

// Function to load user credentials from a binary file
bool loadCredentials(QString &username, QString &password)
{
    QFile file("credentials.dat");
    if (!file.open(QIODevice::ReadOnly)) {
        QMessageBox::critical(nullptr, "Error", "Failed to open file for loading credentials.");
        return false;
    }

    QDataStream in(&file);
    in >> username >> password;
    file.close();

    return true;
}
void MainWindow::on_pushButton_clicked()
{
    QString inputUsername = ui->lineEdit_name->text();
    QString inputPassword = ui->lineEdit_password->text();

    if (inputUsername.isEmpty() || inputPassword.isEmpty()) {
        QMessageBox::warning(this, "Incomplete Details",
                             "<p style='color:#E94560; font-weight:bold;'>"
                             "Please enter both username and password to continue.</p>");
        return;
    }

    QString storedUsername, storedPassword;
    if (!loadCredentials(storedUsername, storedPassword)) {
        return; // Stop if credentials cannot be loaded
    }

    if (inputUsername == storedUsername && inputPassword == storedPassword) {
        QMessageBox::information(this, "Login Successful",
                                 "<p style='color:#4CAF50; font-weight:bold;'>"
                                 "Welcome " + inputUsername + "! You have successfully logged in. "
                                                       "Enjoy exploring the app!</p>");


        second *sec = new second(this);
        sec->setModal(true);
        sec->exec();

        delete sec; // Clean up
    } else {
        QMessageBox::critical(this, "Login Failed",
                              "<p style='color:#E94560; font-weight:bold;'>"
                              "The username or password you entered is incorrect. "
                              "Please try again.</p>");
    }
}

void MainWindow::on_pushButton_2_clicked()
{
    signup *sec = new signup(this);
    sec->setModal(true);
    sec->exec();
}




