#include "bills.h"
#include "ui_bills.h"

Bills::Bills(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Bills)
{
    ui->setupUi(this);
}

Bills::~Bills()
{
    delete ui;
}
